export enum User{
    admin = 1,
    manager = 2,
    general = 3
}